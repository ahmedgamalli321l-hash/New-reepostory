package com.ahmed.breadsales

import android.app.*
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ahmed.breadsales.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:AppCompatActivity(){
 private lateinit var db:AppDb
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);db=AppDb.get(this)
  findViewById<Button>(R.id.btnStock).setOnClickListener{stockDialog()}
  findViewById<Button>(R.id.btnSale).setOnClickListener{saleDialog(false)}
  findViewById<Button>(R.id.btnReturn).setOnClickListener{saleDialog(true)}
  findViewById<Button>(R.id.btnReport).setOnClickListener{report()}
 }
 private fun stockDialog(){ val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;val n=EditText(this);n.hint="اسم الصنف";val p=EditText(this);p.hint="سعر الحبة";p.inputType=2;val q=EditText(this);q.hint="المخزون بالحبة";q.inputType=2;l.addView(n);l.addView(p);l.addView(q); AlertDialog.Builder(this).setTitle("إضافة صنف").setView(l).setPositiveButton("حفظ"){_,_->lifecycleScope.launch{db.dao().addProduct(Product(name=n.text.toString(),piecePrice=p.text.toString().toDoubleOrNull()?:0.0,stockPieces=q.text.toString().toIntOrNull()?:0));toast("تم الحفظ")}}.setNegativeButton("إلغاء",null).show() }
 private fun saleDialog(ret:Boolean){ lifecycleScope.launch{val ps=db.dao().products();if(ps.isEmpty()){toast("أضف الأصناف أولاً");return@launch};val names=ps.map{it.name}.toTypedArray();var ix=0;val q=EditText(this@MainActivity);q.hint="عدد الحبات";q.inputType=2;AlertDialog.Builder(this@MainActivity).setTitle(if(ret)"مرتجع" else "بيع جديد").setSingleChoiceItems(names,0){_,w->ix=w}.setView(q).setPositiveButton("حفظ"){_,_->lifecycleScope.launch{val p=ps[ix];val qty=q.text.toString().toIntOrNull()?:0;if(qty<=0){toast("اكتب عدد الحبات");return@launch};val total=qty*p.piecePrice;if(ret){val id=db.dao().addReturn(ReturnDoc(total=total));db.dao().addReturnItems(listOf(ReturnItem(returnId=id.toInt(),productId=p.id,qtyPieces=qty,unitPrice=p.piecePrice,lineTotal=total)));db.dao().addStock(p.id,qty);toast("تم تسجيل المرتجع") }else{if(db.dao().takeStock(p.id,qty)==0){toast("المخزون غير كافٍ");return@launch};val id=db.dao().addSale(Sale(total=total));db.dao().addSaleItems(listOf(SaleItem(saleId=id.toInt(),productId=p.id,qtyPieces=qty,unitPrice=p.piecePrice,lineTotal=total)));toast("تم تسجيل البيع")}}}.setNegativeButton("إلغاء",null).show()}}
 private fun report(){val cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);val a=cal.timeInMillis;val b=a+86400000-1;lifecycleScope.launch{val g=db.dao().gross(a,b);val r=db.dao().returns(a,b);AlertDialog.Builder(this@MainActivity).setTitle("تقرير اليوم").setMessage("إجمالي المبيعات: %.2f ر.س\nالمرتجعات: %.2f ر.س\nصافي المبيعات: %.2f ر.س".format(g,r,g-r)).setPositiveButton("تمام",null).show()}}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
