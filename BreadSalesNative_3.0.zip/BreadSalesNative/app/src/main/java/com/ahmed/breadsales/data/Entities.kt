package com.ahmed.breadsales.data

import androidx.room.*

@Entity
data class Product(@PrimaryKey(autoGenerate=true) val id:Int=0, val name:String, val piecePrice:Double, val stockPieces:Int)
@Entity
data class Sale(@PrimaryKey(autoGenerate=true) val id:Int=0, val createdAt:Long=System.currentTimeMillis(), val total:Double)
@Entity
data class SaleItem(@PrimaryKey(autoGenerate=true) val id:Int=0, val saleId:Int, val productId:Int, val qtyPieces:Int, val unitPrice:Double, val lineTotal:Double)
@Entity
data class ReturnDoc(@PrimaryKey(autoGenerate=true) val id:Int=0, val createdAt:Long=System.currentTimeMillis(), val total:Double)
@Entity
data class ReturnItem(@PrimaryKey(autoGenerate=true) val id:Int=0, val returnId:Int, val productId:Int, val qtyPieces:Int, val unitPrice:Double, val lineTotal:Double)
