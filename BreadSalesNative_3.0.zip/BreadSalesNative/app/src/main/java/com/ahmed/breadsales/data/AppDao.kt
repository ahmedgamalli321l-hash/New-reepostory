package com.ahmed.breadsales.data
import androidx.room.*

@Dao interface AppDao {
 @Query("SELECT * FROM Product ORDER BY id") suspend fun products():List<Product>
 @Insert suspend fun addProduct(p:Product):Long
 @Update suspend fun updateProduct(p:Product)
 @Query("UPDATE Product SET stockPieces = stockPieces + :qty WHERE id=:id") suspend fun addStock(id:Int,qty:Int)
 @Query("UPDATE Product SET stockPieces = stockPieces - :qty WHERE id=:id AND stockPieces >= :qty") suspend fun takeStock(id:Int,qty:Int):Int
 @Insert suspend fun addSale(s:Sale):Long
 @Insert suspend fun addSaleItems(items:List<SaleItem>)
 @Insert suspend fun addReturn(r:ReturnDoc):Long
 @Insert suspend fun addReturnItems(items:List<ReturnItem>)
 @Query("SELECT COALESCE(SUM(total),0) FROM Sale WHERE createdAt BETWEEN :a AND :b") suspend fun gross(a:Long,b:Long):Double
 @Query("SELECT COALESCE(SUM(total),0) FROM ReturnDoc WHERE createdAt BETWEEN :a AND :b") suspend fun returns(a:Long,b:Long):Double
}
