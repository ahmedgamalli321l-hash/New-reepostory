package com.ahmed.breadsales.data
import android.content.Context
import androidx.room.*

@Database(entities=[Product::class,Sale::class,SaleItem::class,ReturnDoc::class,ReturnItem::class],version=1,exportSchema=false)
abstract class AppDb:RoomDatabase(){ abstract fun dao():AppDao
 companion object { @Volatile private var I:AppDb?=null
  fun get(c:Context)=I?:synchronized(this){ I?:Room.databaseBuilder(c.applicationContext,AppDb::class.java,"bread_sales.db").build().also{I=it} }
 }
}
